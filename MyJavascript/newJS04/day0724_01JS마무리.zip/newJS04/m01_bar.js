//let menu='짜장';
//console.log(`** bar.js menu=${menu}`);
var menu='짜장';
console.log(`** bar.js menu=${window.menu}`);
