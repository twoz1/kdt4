var menu='짬뽕';
console.log(`** foo.js: menu=${window.menu}`);
//let menu='짬뽕';
//console.log(`** foo.js: menu=${menu}`);